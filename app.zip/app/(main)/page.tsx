

import { IoIosSearch, IoIosCheckmarkCircle } from "react-icons/io";
import { FaAngleDown } from "react-icons/fa6";
import HeroSearch from "@/components/heroSearch";

export default function Section() {
  return (
    <div className="">
      <div className="absolute top-0 w-full lg:h-[95%] bg-[url('/images/hero1.jpeg')] bg-cover bg-center bg-no-repeat">
        <div className="bg-black/50 w-full h-full">
          <div className="w-[700px] ml-[100px]  h-full flex flex-col justify-center">
            <p className="text-[#70f46d] font-medium text-[16px]">
              Find Your Perfect Car
            </p>
            <h1 className="text-white font-bold text-[50px]">
              Looking for a vehicle? <br />
              You’re in the perfect spot.
            </h1>
            <div className="flex text-white gap-5 font-medium text-[13px] mt-[30px]">
              <p className="flex items-center gap-1">
                <IoIosCheckmarkCircle className="size-6 text-[#70f46d]" />
                High quality at a low cost
              </p>
              <p className="flex items-center gap-1">
                <IoIosCheckmarkCircle className="size-6 text-[#70f46d]" />
                Premium services.
              </p>
              <p className="flex items-center gap-1">
                <IoIosCheckmarkCircle className="size-6 text-[#70f46d]" />
                24/7 roadside support.
              </p>
            </div>
          </div>
          
        </div>
      </div>


     <div className=" relative mt-[41em] w-full flex items-center justify-center">
          
          <div className="lg:w-[60%]">
               <HeroSearch/>
          </div>

     </div>


    </div>
  );
}
