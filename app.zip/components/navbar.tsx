

import Link from "next/link";
import { FaPhoneAlt } from "react-icons/fa";
import { IoIosMail, IoMdPerson } from "react-icons/io";
import { FaArrowRightLong } from "react-icons/fa6";
import { TbSteeringWheelFilled } from "react-icons/tb";
import { PiSquaresFourLight } from "react-icons/pi";
import { MdOutlineWbSunny } from "react-icons/md";

export default function Header1() {
  return (
    <div className="">
      <header className="bg-transparent fixed top-0 right-0 left-0 z-30">
        <div className="border-b-[0.25px] border-[#b0abab] px-3 py-2 flex item-center justify-between">
          <div className="flex text-white gap-5 text-[13px]">
            <p className="flex gap-2 items-center">
              <FaPhoneAlt /> +2348063577401
            </p>
            <p className="flex gap-2 items-center">
              <IoIosMail /> montfortv22@gmail.com
            </p>
          </div>
          <div className="flex gap-3">
            <p className="text-white text-[13px]">
              More than <span className="text-[15px] text-[#70f46d]">800+</span>{" "}
              special collection cars in this summer
            </p>
            <button className="bg-[#70f46d] px-3 rounded-[20px] cursor-pointer flex items-center gap-2 text-[12px] font-semibold">
              Access Now <FaArrowRightLong />
            </button>
          </div>
          <div className="flex item-center justify-center text-white text-[13px]">
            <p className="px-3">EN</p>
            <p className="px-3 border-r border-[#b0abab] border-l p">USD</p>
            <p className="px-5 flex items-center">
              <MdOutlineWbSunny className="size-4 text-black-400" />
            </p>
          </div>
        </div>
        <div className="border-b border-[#b0abab] px-3 py-3 flex items-center justify-between">
          <div className="flex item-center">
            <div className="px-5"></div>
            <p className="font-bold text-white text-[30px] flex gap-2">
              <TbSteeringWheelFilled className="size-12 text-[#70f46d]" />{" "}
              Carento
            </p>
          </div>
          <div className="text-white flex gap-5 items-center">
            <Link href="">Home</Link>
            <Link href="">Vehicle</Link>
            <Link href="">Dealers</Link>
            <Link href="">Shop</Link>
            <Link href="">Pages</Link>
            <Link href="">News</Link>
            <Link href="">Dashboard</Link>
            <Link href="">Contact</Link>
          </div>
          <div className="flex gap-3">
            <button className="text-white rounded-[10px] text-[13px] px-3 py-2 font-medium cursor-pointer hover:bg-[#70f46d] flex gap-1 items-center">
              <IoMdPerson className="size-4" />
              Sign in
            </button>
            <button className="bg-white rounded-[10px] text-[13px] px-3 py-2 font-medium cursor-pointer hover:bg-[#70f46d]">
              Add Listing
            </button>
            <div className="py-1 px-2 bg-[#70f46d] rounded-[10px] flex items-center">
              <PiSquaresFourLight className="size-5" />
            </div>
          </div>
        </div>
      </header>
    </div>
  );
}
